上：w
下：s
左：a
右：d
shoot：J