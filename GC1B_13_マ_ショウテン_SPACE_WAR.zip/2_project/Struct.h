#pragma once
typedef struct {
	float x;
	float y;
}Vector2f;