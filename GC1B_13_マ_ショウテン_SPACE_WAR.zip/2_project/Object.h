#pragma once
#include "Struct.h"
class Object
{
protected:
	Vector2f pos_;
	Vector2f speed_;
	float width;
	float height;
	bool isAlive_;
};

